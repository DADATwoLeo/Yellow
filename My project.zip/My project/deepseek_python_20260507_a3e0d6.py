import json
import re
from typing import Optional
from config import LLM_CONFIG

class LLMClient:
    """LLM客户端，支持真实API和模拟模式"""
    
    def __init__(self):
        self.api_key = LLM_CONFIG.get("api_key")
        self.model = LLM_CONFIG.get("model", "deepseek-chat")
        self.base_url = LLM_CONFIG.get("base_url")
        self.client = None
        
        # 如果有API Key，初始化真实客户端
        if self.api_key:
            try:
                from openai import OpenAI
                self.client = OpenAI(
                    api_key=self.api_key,
                    base_url=self.base_url
                )
                print("[LLM] 已连接真实LLM服务")
            except ImportError:
                print("[LLM] openai库未安装，使用模拟模式")
            except Exception as e:
                print(f"[LLM] 连接失败: {e}，使用模拟模式")
        else:
            print("[LLM] 未配置API Key，使用模拟模式")
    
    def chat(self, system_prompt: str, user_prompt: str, temperature: float = 0.1) -> str:
        """调用LLM进行对话"""
        if self.client:
            return self._real_chat(system_prompt, user_prompt, temperature)
        else:
            return self._simulated_chat(system_prompt, user_prompt)
    
    def _real_chat(self, system_prompt: str, user_prompt: str, temperature: float) -> str:
        """真实API调用"""
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                temperature=temperature,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ]
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"[LLM] API调用失败: {e}")
            return self._simulated_chat(system_prompt, user_prompt)
    
    def _simulated_chat(self, system_prompt: str, user_prompt: str) -> str:
        """模拟LLM响应（基于规则的推理）"""
        user_lower = user_prompt.lower()
        
        # 检测是否是违规判定请求
        if "is_violation" in system_prompt.lower() or "违规" in system_prompt:
            return self._simulate_violation_judgment(user_prompt)
        
        # 检测是否是冲突裁决请求
        if "final_verdict" in system_prompt.lower() or "裁决" in system_prompt:
            return self._simulate_conflict_resolution(user_prompt)
        
        # 默认响应
        return json.dumps({
            "analysis": "基于规则引擎的模拟分析",
            "confidence": 0.7
        }, ensure_ascii=False)
    
    def _simulate_violation_judgment(self, user_prompt: str) -> str:
        """模拟违规判断"""
        # 如果代码中明显存在print/log + PII的组合
        has_print = "print" in user_prompt.lower()
        has_log = "log" in user_prompt.lower() or "logging" in user_prompt.lower()
        has_pii = any(kw in user_prompt.lower() for kw in ["phone", "email", "id_card", "身份证", "手机", "邮箱", "credit_card"])
        has_mask = any(kw in user_prompt.lower() for kw in ["mask", "脱敏", "****", "隐藏"])
        
        if has_mask:
            return json.dumps({
                "is_violation": False,
                "reasoning": "代码中对PII数据进行了脱敏处理（如mask/星号替换），符合数据最小化原则和脱敏要求。",
                "confidence": 0.85,
                "applied_laws": ["GDPR-Art.32", "PIPL-Art.51"]
            }, ensure_ascii=False)
        
        if (has_print or has_log) and has_pii:
            return json.dumps({
                "is_violation": True,
                "reasoning": "检测到敏感个人信息（PII）通过print/log直接输出，存在明文泄露风险。违反GDPR第32条关于数据加密和假名化的要求，以及PIPL第51条关于防止信息泄露的规定。",
                "confidence": 0.92,
                "applied_laws": ["GDPR-Art.32", "PIPL-Art.51", "CCPA-1798.150"]
            }, ensure_ascii=False)
        
        return json.dumps({
            "is_violation": False,
            "reasoning": "未检测到明确的PII泄露模式，代码基本合规。",
            "confidence": 0.75
        }, ensure_ascii=False)
    
    def _simulate_conflict_resolution(self, user_prompt: str) -> str:
        """模拟多Agent冲突裁决"""
        has_pii_leak = any(kw in user_prompt.lower() for kw in ["print", "log", "phone", "id_card", "身份证", "手机号"])
        
        if has_pii_leak:
            return json.dumps({
                "final_verdict": "VIOLATION",
                "reasoning": "Auditor最终裁决：尽管Analyzer可能基于上下文认为使用合理，但从数据保护法规的严格解释出发，明文输出PII到日志/控制台构成违规。建议对所有PII数据在输出前进行脱敏处理。",
                "risk_mitigation": "使用数据脱敏函数（如mask_pii）替换原始PII后再输出。",
                "priority": "HIGH"
            }, ensure_ascii=False)
        
        return json.dumps({
            "final_verdict": "COMPLIANT",
            "reasoning": "经过多Agent综合评估，未发现实质性违规。",
            "priority": "LOW"
        }, ensure_ascii=False)