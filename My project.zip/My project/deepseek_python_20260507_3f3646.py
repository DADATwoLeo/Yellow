from typing import List, Dict
from config import PRIVACY_LAWS
import re

class PrivacyLawRetriever:
    """隐私法规RAG检索器"""
    
    def __init__(self):
        self.laws = PRIVACY_LAWS
        # 为每条法规建立关键词索引
        self._build_index()
    
    def _build_index(self):
        """建立关键词倒排索引"""
        self.keyword_index = {}
        keywords_map = {
            "日志": ["log", "logging", "记录", "日志"],
            "打印": ["print", "输出", "打印", "显示", "展示", "console"],
            "加密": ["encrypt", "加密", "encode", "hash", "哈希"],
            "脱敏": ["mask", "脱敏", "隐藏", "hide", "模糊", "星号", "*"],
            "传输": ["send", "传输", "发送", "post", "request", "http"],
            "存储": ["save", "存储", "write", "file", "数据库", "database"],
            "收集": ["collect", "收集", "采集", "获取"],
            "最小化": ["最小", "必要", "minimal"],
            "未经授权": ["unauthorized", "未授权", "public", "公开", "暴露"],
        }
        
        for law_id, law_text in self.laws.items():
            for keyword, aliases in keywords_map.items():
                if any(alias.lower() in law_text.lower() for alias in aliases):
                    if law_id not in self.keyword_index:
                        self.keyword_index[law_id] = set()
                    self.keyword_index[law_id].add(keyword)
    
    def retrieve(self, query: str, top_k: int = 3) -> List[Dict]:
        """
        根据查询检索相关法规
        query: 包含代码上下文、风险描述的查询文本
        """
        scores = {}
        query_lower = query.lower()
        
        # 关键词扩展映射
        query_expansion = {
            "print": ["日志", "打印", "输出"],
            "log": ["日志", "记录"],
            "email": ["传输", "存储"],
            "phone": ["存储", "脱敏"],
            "id_card": ["存储", "加密", "脱敏"],
            "credit_card": ["加密", "存储"],
        }
        
        # 扩展查询关键词
        expanded_terms = [query_lower]
        for term, expansions in query_expansion.items():
            if term in query_lower:
                expanded_terms.extend(expansions)
        
        # 计算每条法规的相关性分数
        for law_id, keywords in self.keyword_index.items():
            score = 0
            for term in expanded_terms:
                if any(kw.lower() in term for kw in keywords):
                    score += 1
            if score > 0:
                # 加入法规文本长度归一化（避免长法规占优）
                scores[law_id] = score / (len(self.laws[law_id]) ** 0.3)
        
        # 排序并返回top_k结果
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_k]
        
        return [
            {
                "law_id": law_id,
                "content": self.laws[law_id],
                "relevance_score": round(score, 2)
            }
            for law_id, score in ranked
        ]