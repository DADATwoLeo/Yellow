# 1. 创建项目目录
mkdir -p privacy_audit_system/{agents,tools,data}

# 2. 将上述所有代码复制到对应文件

# 3. 运行（无需安装任何依赖）
cd privacy_audit_system
python main.py