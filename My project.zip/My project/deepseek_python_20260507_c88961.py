import os

# LLM配置（设置为None则使用模拟模式）
LLM_CONFIG = {
    "provider": "deepseek",
    "api_key": os.getenv("DEEPSEEK_API_KEY"),  # None则自动切换模拟模式
    "model": "deepseek-chat",
    "base_url": "https://api.deepseek.com/v1"
}

# PII数据类型及正则匹配
PII_PATTERNS = {
    "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
    "phone_cn": r'\b1[3-9]\d{9}\b',
    "id_card_cn": r'\b\d{17}[\dXx]\b',
    "credit_card": r'\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b',
    "ip_address": r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',
}

# 危险的数据出口（sink）
DANGEROUS_SINKS = [
    "print", "log.info", "log.debug", "log.warning", "log.error",
    "logging.info", "logging.debug", "logging.warning", "logging.error",
    "write", "send_email", "send_sms", "http_post", "file.write"
]

# 隐私法规条款
PRIVACY_LAWS = {
    "GDPR-Art.32": "数据控制者和处理者必须实施适当的技术和组织措施，确保与风险相称的安全水平，包括个人数据的假名化和加密。",
    "GDPR-Art.5.1.c": "个人数据应充分、相关且限于处理目的所必需的范围（数据最小化原则）。",
    "PIPL-Art.51": "个人信息处理者应当根据个人信息的处理目的、处理方式、个人信息的种类以及对个人权益的影响、可能存在的安全风险等，采取措施防止个人信息泄露、篡改、丢失。",
    "PIPL-Art.6": "处理个人信息应当具有明确、合理的目的，并应当与处理目的直接相关，采取对个人权益影响最小的方式。",
    "CCPA-1798.100": "消费者有权要求收集个人信息的企业披露其收集的个人信息类别和具体内容。",
    "CCPA-1798.150": "企业必须实施合理的安全程序和做法来保护个人信息免受未经授权的访问。"
}