import json
from tools.rag_retriever import PrivacyLawRetriever
from tools.llm_client import LLMClient
from typing import Dict, Any

class AnalyzerAgent:
    """
    Agent 2: 语义分析Agent
    职责：使用RAG检索法规，结合LLM进行上下文语义分析
    """
    
    def __init__(self):
        self.name = "AnalyzerAgent"
        self.role = "语义理解与法规对齐"
        self.retriever = PrivacyLawRetriever()
        self.llm = LLMClient()
    
    def analyze(self, scanner_result: Dict[str, Any], original_code: str) -> Dict[str, Any]:
        """执行语义分析"""
        print(f"\n{'='*50}")
        print(f"[{self.name}] 开始语义分析...")
        print(f"{'='*50}")
        
        risk_flags = scanner_result.get("risk_flags", [])
        
        if not risk_flags:
            print(f"[{self.name}] 无风险点需要分析")
            return {
                "agent": self.name,
                "status": "CLEAN",
                "analysis_results": [],
                "conclusion": "未发现需要深度分析的风险点"
            }
        
        analysis_results = []
        
        for flag in risk_flags:
            print(f"\n[{self.name}] 分析风险点: {flag['id']}")
            
            # Step 1: RAG检索相关法规
            query = self._build_rag_query(flag)
            relevant_laws = self.retriever.retrieve(query, top_k=3)
            
            print(f"[{self.name}] RAG检索到 {len(relevant_laws)} 条相关法规:")
            for law in relevant_laws:
                print(f"  - {law['law_id']}: {law['content'][:50]}...")
            
            # Step 2: LLM语义分析
            llm_analysis = self._llm_analyze(flag, relevant_laws, original_code)
            
            # Step 3: 综合判断
            analysis_result = {
                "risk_id": flag['id'],
                "original_flag": flag,
                "relevant_laws": relevant_laws,
                "llm_analysis": llm_analysis,
                "synthesized_judgment": self._synthesize(flag, relevant_laws, llm_analysis)
            }
            
            analysis_results.append(analysis_result)
            
            judgment = analysis_result['synthesized_judgment']
            print(f"[{self.name}] 判断: {'违规' if judgment['is_violation'] else '合规'} (置信度: {judgment['confidence']})")
        
        # 汇总
        violations = [r for r in analysis_results if r['synthesized_judgment']['is_violation']]
        compliant = [r for r in analysis_results if not r['synthesized_judgment']['is_violation']]
        
        return {
            "agent": self.name,
            "status": "ANALYZED",
            "analysis_results": analysis_results,
            "summary": {
                "total_risks": len(risk_flags),
                "confirmed_violations": len(violations),
                "compliant": len(compliant)
            },
            "conclusion": f"确认{len(violations)}项违规，{len(compliant)}项合规"
        }
    
    def _build_rag_query(self, flag: Dict) -> str:
        """构建RAG查询"""
        parts = [
            flag.get('description', ''),
            f"sink: {flag.get('sink', '')}",
            f"variable: {flag.get('variable', '')}",
            flag.get('code_snippet', '')
        ]
        return " ".join(parts)
    
    def _llm_analyze(self, flag: Dict, laws: list, code_context: str) -> Dict:
        """使用LLM进行深度分析"""
        system_prompt = """你是一位资深隐私合规专家，精通GDPR、PIPL、CCPA等全球隐私法规。
请严格以JSON格式输出分析结果：
{
    "is_violation": true/false,
    "reasoning": "详细推理过程",
    "confidence": 0.0-1.0,
    "violated_laws": ["法规ID列表"],
    "suggested_fix": "修复建议"
}"""
        
        laws_text = "\n".join([f"{law['law_id']}: {law['content']}" for law in laws])
        
        user_prompt = f"""
## 代码风险点
- 描述: {flag.get('description', '')}
- 代码片段: {flag.get('code_snippet', '')}
- 变量: {flag.get('variable', '')}
- 出口: {flag.get('sink', '')}

## 相关法规
{laws_text}

请判断上述代码是否构成隐私违规。
"""
        
        response = self.llm.chat(system_prompt, user_prompt)
        
        try:
            # 尝试解析JSON
            return json.loads(response)
        except json.JSONDecodeError:
            # 如果解析失败，尝试从响应中提取JSON
            import re
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                try:
                    return json.loads(json_match.group())
                except:
                    pass
            return {"is_violation": True, "reasoning": "LLM响应解析失败", "confidence": 0.5}
    
    def _synthesize(self, flag: Dict, laws: list, llm_result: Dict) -> Dict:
        """综合RAG和LLM结果"""
        return {
            "is_violation": llm_result.get("is_violation", False),
            "confidence": llm_result.get("confidence", 0.5),
            "reasoning": llm_result.get("reasoning", ""),
            "violated_laws": llm_result.get("violated_laws", [law['law_id'] for law in laws]),
            "suggested_fix": llm_result.get("suggested_fix", "建议对敏感数据进行脱敏处理"),
            "evidence": {
                "rag_laws": [law['law_id'] for law in laws],
                "code_pattern": flag.get('type', ''),
            }
        }