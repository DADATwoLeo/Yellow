import re
import ast
from typing import List, Dict, Any
from config import PII_PATTERNS, DANGEROUS_SINKS

class CodeParser:
    """Python代码静态分析器，识别PII并追踪数据流"""
    
    def __init__(self, code: str):
        self.code = code
        self.tree = None
        self.all_variables = {}  # 变量名 -> 定义信息
        self.data_flows = []     # 数据流转记录
        
        try:
            self.tree = ast.parse(code)
            self._build_variable_table()
            self._trace_data_flow()
        except SyntaxError as e:
            print(f"[Parser] 语法错误: {e}")

    def _get_node_source(self, node) -> str:
        """获取AST节点的源代码片段"""
        try:
            return ast.get_source_segment(self.code, node) or ""
        except:
            return ""

    def _build_variable_table(self):
        """构建变量定义表"""
        if not self.tree:
            return
            
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Assign):
                source = self._get_node_source(node)
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        var_name = target.id
                        # 检测PII类型
                        pii_types = []
                        for pii_type, pattern in PII_PATTERNS.items():
                            if re.search(pattern, source):
                                pii_types.append(pii_type)
                        
                        self.all_variables[var_name] = {
                            "line": node.lineno,
                            "source": source,
                            "pii_types": pii_types,
                            "is_pii": len(pii_types) > 0
                        }

    def _trace_data_flow(self):
        """追踪PII变量的使用链"""
        if not self.tree:
            return
            
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Call):
                # 判断调用的函数/方法
                func_name = self._get_function_name(node)
                if func_name in DANGEROUS_SINKS:
                    # 检查参数中是否包含PII变量
                    for arg in node.args:
                        if isinstance(arg, ast.Name) and arg.id in self.all_variables:
                            var_info = self.all_variables[arg.id]
                            if var_info["is_pii"]:
                                self.data_flows.append({
                                    "type": "PII_TO_SINK",
                                    "variable": arg.id,
                                    "pii_categories": var_info["pii_types"],
                                    "sink": func_name,
                                    "line": node.lineno,
                                    "code": self._get_node_source(node),
                                    "severity": "HIGH"
                                })
                    
                    # 检查关键字参数
                    for kw in node.keywords:
                        if isinstance(kw.value, ast.Name) and kw.value.id in self.all_variables:
                            var_info = self.all_variables[kw.value.id]
                            if var_info["is_pii"]:
                                self.data_flows.append({
                                    "type": "PII_TO_SINK",
                                    "variable": kw.value.id,
                                    "pii_categories": var_info["pii_types"],
                                    "sink": func_name,
                                    "line": node.lineno,
                                    "code": self._get_node_source(node),
                                    "severity": "HIGH"
                                })

    def _get_function_name(self, node: ast.Call) -> str:
        """提取函数调用的名称"""
        if isinstance(node.func, ast.Name):
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            obj = self._get_node_source(node.func.value) if hasattr(node.func, 'value') else ""
            return f"{obj}.{node.func.attr}" if obj else node.func.attr
        return ""

    def get_pii_variables(self) -> List[Dict]:
        """获取所有PII变量"""
        return [
            {"name": name, **info}
            for name, info in self.all_variables.items()
            if info["is_pii"]
        ]

    def get_data_flows(self) -> List[Dict]:
        """获取数据流转到危险出口的记录"""
        return self.data_flows

    def get_summary(self) -> Dict:
        """生成分析摘要"""
        return {
            "total_variables": len(self.all_variables),
            "pii_variables": self.get_pii_variables(),
            "dangerous_flows": self.data_flows,
            "risk_score": min(len(self.data_flows) * 25, 100)  # 每个泄露点25分，满分100
        }