import json
from tools.code_parser import CodeParser
from typing import Dict, Any

class ScannerAgent:
    """
    Agent 1: 静态扫描Agent
    职责：扫描代码，识别PII变量，追踪数据流向危险出口
    """
    
    def __init__(self):
        self.name = "ScannerAgent"
        self.role = "静态代码分析与数据流追踪"
    
    def scan(self, code: str) -> Dict[str, Any]:
        """执行扫描任务"""
        print(f"\n{'='*50}")
        print(f"[{self.name}] 开始静态扫描...")
        print(f"{'='*50}")
        
        parser = CodeParser(code)
        
        # 获取分析结果
        pii_vars = parser.get_pii_variables()
        data_flows = parser.get_data_flows()
        summary = parser.get_summary()
        
        # 构建结构化输出
        result = {
            "agent": self.name,
            "timestamp": "2024-01-01T00:00:00Z",  # 实际应用中使用datetime
            "findings": {
                "pii_variables": pii_vars,
                "data_flows": data_flows,
                "risk_summary": summary
            },
            "risk_flags": self._generate_risk_flags(data_flows),
            "confidence": self._calculate_confidence(data_flows, pii_vars)
        }
        
        # 输出扫描结果
        print(f"[{self.name}] 发现 {len(pii_vars)} 个PII变量")
        for var in pii_vars:
            print(f"  - {var['name']}: {', '.join(var['pii_types'])} (行{var['line']})")
        
        print(f"[{self.name}] 发现 {len(data_flows)} 个数据泄露路径")
        for flow in data_flows:
            print(f"  - [{flow['severity']}] {flow['variable']} -> {flow['sink']} (行{flow['line']})")
        
        return result
    
    def _generate_risk_flags(self, data_flows: list) -> list:
        """基于数据流生成风险标记"""
        flags = []
        for flow in data_flows:
            flags.append({
                "id": f"RISK-{flow['line']}-{flow['variable']}",
                "type": "DATA_LEAK",
                "severity": flow['severity'],
                "variable": flow['variable'],
                "sink": flow['sink'],
                "line": flow['line'],
                "code_snippet": flow['code'],
                "description": f"变量 '{flow['variable']}' (包含{flow['pii_categories']}) 直接传递到危险出口 '{flow['sink']}'"
            })
        return flags
    
    def _calculate_confidence(self, data_flows: list, pii_vars: list) -> float:
        """计算扫描置信度"""
        if not pii_vars:
            return 0.9  # 没有PII，高置信度认为安全
        if data_flows:
            return 0.95  # 有明确的泄露路径，高置信度
        return 0.6  # 有PII但没发现泄露路径，中等置信度