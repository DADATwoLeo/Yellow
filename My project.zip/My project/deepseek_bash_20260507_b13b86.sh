# 安装依赖
pip install openai

# 设置API Key
export DEEPSEEK_API_KEY="sk-your-real-api-key"

# 运行
python main.py