import json
from tools.llm_client import LLMClient
from typing import Dict, Any, List

class AuditorAgent:
    """
    Agent 3: 合规裁判Agent
    职责：接收Scanner和Analyzer的结果，处理冲突，生成最终审计报告
    包含长链推理和辩论机制
    """
    
    def __init__(self):
        self.name = "AuditorAgent"
        self.role = "合规裁判与冲突解决"
        self.llm = LLMClient()
        self.debate_log = []  # 辩论记录
    
    def audit(self, scanner_result: Dict[str, Any], analyzer_result: Dict[str, Any]) -> Dict[str, Any]:
        """执行最终审计"""
        print(f"\n{'='*50}")
        print(f"[{self.name}] 开始最终审计...")
        print(f"{'='*50}")
        
        # Step 1: 检测冲突
        print(f"\n[{self.name}] 步骤1: 检测Agent间冲突...")
        conflicts = self._detect_conflicts(scanner_result, analyzer_result)
        
        if conflicts:
            print(f"[{self.name}] 发现 {len(conflicts)} 处冲突")
            # Step 2: 辩论机制解决冲突
            print(f"\n[{self.name}] 步骤2: 启动辩论机制...")
            resolved_conflicts = self._resolve_conflicts(conflicts)
        else:
            print(f"[{self.name}] 未发现冲突，Scanner和Analyzer结论一致")
            resolved_conflicts = []
        
        # Step 3: 长链推理综合评估
        print(f"\n[{self.name}] 步骤3: 长链推理综合评估...")
        comprehensive_assessment = self._comprehensive_reasoning(
            scanner_result, 
            analyzer_result, 
            resolved_conflicts
        )
        
        # Step 4: 生成最终报告
        print(f"\n[{self.name}] 步骤4: 生成审计报告...")
        final_report = self._generate_final_report(
            scanner_result,
            analyzer_result,
            resolved_conflicts,
            comprehensive_assessment
        )
        
        return final_report
    
    def _detect_conflicts(self, scanner: Dict, analyzer: Dict) -> List[Dict]:
        """
        检测Scanner和Analyzer之间的冲突
        Scanner标记为风险，但Analyzer判断为合规 -> 冲突
        """
        conflicts = []
        
        scanner_flags = scanner.get("risk_flags", [])
        analyzer_results = analyzer.get("analysis_results", [])
        
        for s_flag in scanner_flags:
            # 查找对应的分析结果
            matching = None
            for a_result in analyzer_results:
                if a_result.get("risk_id") == s_flag.get("id"):
                    matching = a_result
                    break
            
            if matching:
                s_severity = s_flag.get("severity", "LOW")
                a_is_violation = matching.get("synthesized_judgment", {}).get("is_violation", False)
                
                # Scanner认为是HIGH，但Analyzer认为合规 -> 冲突
                if s_severity == "HIGH" and not a_is_violation:
                    conflicts.append({
                        "conflict_id": f"CONFLICT-{s_flag['id']}",
                        "scanner_position": {
                            "verdict": "VIOLATION",
                            "severity": s_severity,
                            "detail": s_flag.get("description", "")
                        },
                        "analyzer_position": {
                            "verdict": "COMPLIANT",
                            "reasoning": matching.get("synthesized_judgment", {}).get("reasoning", "")
                        },
                        "context": {
                            "code": s_flag.get("code_snippet", ""),
                            "line": s_flag.get("line", 0)
                        }
                    })
        
        return conflicts
    
    def _resolve_conflicts(self, conflicts: List[Dict]) -> List[Dict]:
        """通过辩论机制解决冲突"""
        resolved = []
        
        for conflict in conflicts:
            print(f"\n[{self.name}] 辩论: {conflict['conflict_id']}")
            print(f"  Scanner认为: 违规")
            print(f"  Analyzer认为: 合规")
            
            # 构建辩论prompt
            system_prompt = """你是首席隐私合规审计官，需要裁决两个AI Agent的分歧。
Scanner（静态分析专家）和Analyzer（语义分析专家）对同一代码片段有不同判断。
请基于法规严格性、风险最小化原则做出最终裁决。

输出JSON格式：
{
    "final_verdict": "VIOLATION" 或 "COMPLIANT",
    "reasoning": "详细裁决理由",
    "risk_mitigation": "风险缓解措施",
    "priority": "HIGH/CRITICAL"
}"""
            
            user_prompt = f"""
## 冲突详情
**Scanner判断**: {json.dumps(conflict['scanner_position'], ensure_ascii=False)}
**Analyzer判断**: {json.dumps(conflict['analyzer_position'], ensure_ascii=False)}
**代码上下文**: {conflict['context'].get('code', '')}

请做出最终裁决。
"""
            
            # 调用LLM进行裁决
            resolution = self.llm.chat(system_prompt, user_prompt)
            
            try:
                resolution_json = json.loads(resolution)
            except:
                # 从宽原则：如果有PII到sink的路径，从严判定
                resolution_json = {
                    "final_verdict": "VIOLATION",
                    "reasoning": "存在明确的PII到危险出口的路径，从风险最小化原则出发，判定为违规。",
                    "risk_mitigation": "对PII数据进行脱敏处理后再输出",
                    "priority": "HIGH"
                }
            
            resolved.append({
                "conflict_id": conflict['conflict_id'],
                "resolution": resolution_json,
                "debate_rounds": 1
            })
            
            print(f"  Auditor裁决: {resolution_json['final_verdict']}")
        
        return resolved
    
    def _comprehensive_reasoning(self, scanner: Dict, analyzer: Dict, resolved_conflicts: List) -> Dict:
        """长链推理综合评估"""
        
        # 收集所有证据
        scanner_risks = len(scanner.get("risk_flags", []))
        analyzer_violations = analyzer.get("summary", {}).get("confirmed_violations", 0)
        conflicts_count = len(resolved_conflicts)
        
        # 推理链
        reasoning_chain = [
            f"Scanner发现{scanner_risks}个风险点",
            f"Analyzer确认{analyzer_violations}个违规",
            f"辩论解决{conflicts_count}个冲突",
        ]
        
        # 综合评分
        risk_score = 0
        if scanner_risks > 0:
            risk_score += min(scanner_risks * 20, 60)
        if analyzer_violations > 0:
            risk_score += min(analyzer_violations * 30, 30)
        if conflicts_count > 0:
            risk_score += 10
        
        risk_level = "LOW"
        if risk_score >= 70:
            risk_level = "CRITICAL"
        elif risk_score >= 40:
            risk_level = "HIGH"
        elif risk_score >= 20:
            risk_level = "MEDIUM"
        
        return {
            "reasoning_chain": reasoning_chain,
            "risk_score": risk_score,
            "risk_level": risk_level,
            "summary": (
                f"经多Agent协作审计，综合风险评分为{risk_score}/100，"
                f"风险等级为{risk_level}。发现{scanner_risks}个潜在风险点，"
                f"确认{analyzer_violations}项违规，已通过辩论机制解决{conflicts_count}个冲突。"
            )
        }
    
    def _generate_final_report(self, scanner: Dict, analyzer: Dict, 
                                conflicts: List, assessment: Dict) -> Dict:
        """生成最终审计报告"""
        
        report = {
            "report_id": "AUDIT-2024-001",
            "generated_by": "多Agent长链推理协作系统",
            "agents_involved": ["ScannerAgent", "AnalyzerAgent", "AuditorAgent"],
            
            "executive_summary": assessment.get("summary", ""),
            
            "detailed_findings": {
                "scanner_findings": {
                    "pii_variables": scanner.get("findings", {}).get("pii_variables", []),
                    "data_leaks": scanner.get("risk_flags", [])
                },
                "analyzer_findings": analyzer.get("analysis_results", []),
                "conflicts_resolved": conflicts
            },
            
            "risk_assessment": {
                "score": assessment.get("risk_score", 0),
                "level": assessment.get("risk_level", "UNKNOWN"),
                "reasoning_chain": assessment.get("reasoning_chain", [])
            },
            
            "recommendations": self._generate_recommendations(scanner, analyzer, conflicts),
            
            "compliance_status": "PASS" if assessment.get("risk_level") == "LOW" else "FAIL",
            
            "audit_trail": {
                "reasoning_chain": assessment.get("reasoning_chain", []),
                "conflict_resolutions": [c.get("resolution", {}) for c in conflicts]
            }
        }
        
        return report
    
    def _generate_recommendations(self, scanner: Dict, analyzer: Dict, conflicts: List) -> List[str]:
        """生成修复建议"""
        recommendations = []
        
        # 基于Scanner发现
        for flag in scanner.get("risk_flags", []):
            recommendations.append(
                f"[行{flag.get('line')}] 变量'{flag.get('variable')}' "
                f"在传递给{flag.get('sink')}前应进行脱敏处理"
            )
        
        if conflicts:
            recommendations.append("建议在CI/CD中集成自动化隐私检查，防止类似冲突再次出现")
        
        if not recommendations:
            recommendations.append("代码符合隐私合规要求，无需修改")
        
        return recommendations