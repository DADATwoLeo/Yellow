#!/usr/bin/env python3
"""
多Agent长链推理协作的自动化隐私合规代码审计系统
==============================================
架构: ScannerAgent -> AnalyzerAgent -> AuditorAgent
特点: 多Agent协作、长链推理、RAG增强、冲突辩论机制
"""

import json
import sys
import os
from datetime import datetime

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from agents.scanner_agent import ScannerAgent
from agents.analyzer_agent import AnalyzerAgent
from agents.auditor_agent import AuditorAgent


def load_sample_code(filepath: str = "data/sample_code.py") -> str:
    """加载待审计的代码"""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        print(f"[Main] 文件未找到: {filepath}，使用内置示例代码")
        return """
import logging
def process(user_data):
    email = "test@example.com"
    phone = "13812345678"
    print(f"用户信息: {email}, {phone}")
    logging.info(f"身份证: 110101199001011234")
        """

def print_separator(title: str = ""):
    """打印分隔线"""
    width = 60
    if title:
        print(f"\n{'='*width}")
        print(f"  {title}")
        print(f"{'='*width}")
    else:
        print(f"{'='*width}")

def main():
    """主流程"""
    print_separator("🔍 多Agent长链推理协作 - 隐私合规代码审计系统")
    print(f"启动时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"协作模式: ScannerAgent → AnalyzerAgent → AuditorAgent")
    
    # 加载代码
    code = load_sample_code()
    print(f"\n📄 已加载待审计代码 ({len(code)} 字符)")
    print(f"{'─'*40}")
    print(code.strip())
    print(f"{'─'*40}")
    
    # ============ Phase 1: Scanner Agent ============
    print_separator("Phase 1: ScannerAgent 静态分析")
    scanner = ScannerAgent()
    scanner_result = scanner.scan(code)
    
    # ============ Phase 2: Analyzer Agent ============
    print_separator("Phase 2: AnalyzerAgent 语义分析 (RAG + LLM)")
    analyzer = AnalyzerAgent()
    analyzer_result = analyzer.analyze(scanner_result, code)
    
    # ============ Phase 3: Auditor Agent ============
    print_separator("Phase 3: AuditorAgent 最终裁判 (辩论+长链推理)")
    auditor = AuditorAgent()
    final_report = auditor.audit(scanner_result, analyzer_result)
    
    # ============ 输出最终报告 ============
    print_separator("📋 最终审计报告")
    print(json.dumps(final_report, ensure_ascii=False, indent=2))
    
    # ============ 摘要 ============
    print_separator("📊 审计摘要")
    print(f"  风险评分: {final_report['risk_assessment']['score']}/100")
    print(f"  风险等级: {final_report['risk_assessment']['level']}")
    print(f"  合规状态: {final_report['compliance_status']}")
    print(f"  推理链: {' → '.join(final_report['risk_assessment']['reasoning_chain'])}")
    
    print(f"\n💡 修复建议:")
    for i, rec in enumerate(final_report.get('recommendations', []), 1):
        print(f"  {i}. {rec}")
    
    print_separator("✅ 审计完成")
    return final_report


if __name__ == "__main__":
    main()