# 示例：包含隐私泄露风险的代码
import logging
import json

class UserDataProcessor:
    """用户数据处理类 - 包含多个隐私合规问题"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def process_user_registration(self, user_data: dict) -> dict:
        """处理用户注册 - 风险点密集"""
        
        # 风险1: 邮箱明文硬编码
        admin_email = "admin@company.com"
        print(f"管理员邮箱: {admin_email}")  # PII泄露到控制台
        
        # 风险2: 手机号未脱敏直接输出
        user_phone = user_data.get("phone", "13812345678")
        print(f"用户手机号: {user_phone}")  # PII泄露
        
        # 风险3: 身份证号写入日志
        id_card = user_data.get("id_card", "110101199001011234")
        self.logger.info(f"用户身份证号: {id_card}")  # PII写入日志
        
        # 风险4: 信用卡号明文存储
        credit_card = "1234-5678-9012-3456"
        self.logger.debug(f"信用卡号: {credit_card}")  # 敏感金融信息泄露
        
        # 正确做法: 脱敏后输出
        masked_phone = user_phone[:3] + "****" + user_phone[7:]
        print(f"脱敏手机号: {masked_phone}")  # 合规
        
        return {"status": "success", "masked_phone": masked_phone}
    
    def export_user_report(self, users: list) -> None:
        """导出用户报告"""
        for user in users:
            # 风险5: 循环中泄露多个用户信息
            print(f"用户名: {user['name']}, 邮箱: {user['email']}")